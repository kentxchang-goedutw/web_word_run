const defaultSettings = {
    isActive: false,
    gasUrl: 'https://script.google.com/macros/s/demo/exec',
    minFontSize: 60,
    maxFontSize: 120,
    minSpeed: 8,
    maxSpeed: 15,
    repeatCount: 3,
    colors: ['#ec4899', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6']
};

document.addEventListener('DOMContentLoaded', () => {
    // 載入儲存的設定
    chrome.storage.local.get(['settings'], (result) => {
        const settings = result.settings || defaultSettings;
        loadSettingsToUI(settings);
    });

    // 數值顯示同步
    setupValueListeners();

    // 儲存按鈕
    document.getElementById('saveBtn').onclick = saveSettings;

    // 開啟訪客發文網址按鈕
    document.getElementById('postUrlBtn').onclick = openPostUrl;

    // 說明按鈕
    document.getElementById('helpBtn').onclick = () => {
        const help = document.getElementById('gasHelp');
        help.style.display = help.style.display === 'none' ? 'block' : 'none';
    };

    // 複製 GAS 程式碼
    document.getElementById('copyGasBtn').onclick = copyGasCode;

    // 清空按鈕
    document.getElementById('clearBtn').onclick = clearCloudData;
});

const gasCode = `function getSheet() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName("跑馬燈資料");
  if (!sheet) {
    sheet = ss.insertSheet("跑馬燈資料");
    sheet.appendRow(["時間", "內容"]);
    sheet.getRange("1:1").setFontWeight("bold").setBackground("#ffe4e6");
  }
  return sheet;
}

function doGet(e) {
  const sheet = getSheet();
  const data = sheet.getDataRange().getValues();
  data.shift(); // 移除標題
  const result = data.map(row => ({ "時間": row[0], "內容": row[1] }));
  
  const callback = e.parameter.callback;
  const json = JSON.stringify(result);
  if (callback) {
    return ContentService.createTextOutput(callback + "(" + json + ")")
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  const sheet = getSheet();
  const params = JSON.parse(e.postData.contents);
  
  if (params.action === "clear") {
    if (sheet.getLastRow() > 1) {
      sheet.getRange(2, 1, sheet.getLastRow() - 1, 2).clearContent();
    }
    return ContentService.createTextOutput("cleared");
  }

  sheet.appendRow([new Date(), params.content]);
  return ContentService.createTextOutput("success");
}`;

function copyGasCode() {
    navigator.clipboard.writeText(gasCode).then(() => {
        const btn = document.getElementById('copyGasBtn');
        const oldText = btn.innerText;
        btn.innerText = "✅ 已複製到剪貼簿！";
        setTimeout(() => btn.innerText = oldText, 2000);
    }).catch(err => {
        console.error('無法複製:', err);
        showStatus("❌ 複製失敗，請手動複製", true);
    });
}

function openPostUrl() {
    const gasUrl = document.getElementById('gasUrl').value.trim();
    if (!gasUrl) {
        showStatus("⚠️ 請先輸入 GAS 網址", true);
        return;
    }
    const baseUrl = "https://kentxchang-goedutw.github.io/web_word_run/";
    const finalUrl = `${baseUrl}?gasurl=${encodeURIComponent(gasUrl)}`;
    window.open(finalUrl, '_blank');
}

function setupValueListeners() {
    const minF = document.getElementById('minFontSize');
    const maxF = document.getElementById('maxFontSize');
    const minS = document.getElementById('minSpeed');
    const maxS = document.getElementById('maxSpeed');
    const rep = document.getElementById('repeatCount');

    const updateFontVal = () => document.getElementById('fontVal').innerText = `${minF.value}-${maxF.value}`;
    const updateSpeedVal = () => document.getElementById('speedVal').innerText = `${minS.value}-${maxS.value}`;
    const updateRepVal = () => document.getElementById('repeatVal').innerText = rep.value;

    minF.oninput = maxF.oninput = updateFontVal;
    minS.oninput = maxS.oninput = updateSpeedVal;
    rep.oninput = updateRepVal;
}

function loadSettingsToUI(s) {
    document.getElementById('isActive').checked = s.isActive;
    document.getElementById('gasUrl').value = s.gasUrl || '';
    document.getElementById('minFontSize').value = s.minFontSize;
    document.getElementById('maxFontSize').value = s.maxFontSize;
    document.getElementById('minSpeed').value = s.minSpeed;
    document.getElementById('maxSpeed').value = s.maxSpeed;
    document.getElementById('repeatCount').value = s.repeatCount;
    
    document.getElementById('fontVal').innerText = `${s.minFontSize}-${s.maxFontSize}`;
    document.getElementById('speedVal').innerText = `${s.minSpeed}-${s.maxSpeed}`;
    document.getElementById('repeatVal').innerText = s.repeatCount;

    if (s.colors) {
        s.colors.forEach((c, i) => {
            const el = document.getElementById(`color${i + 1}`);
            if (el) el.value = c;
        });
    }
}

function saveSettings() {
    const settings = {
        isActive: document.getElementById('isActive').checked,
        gasUrl: document.getElementById('gasUrl').value.trim(),
        minFontSize: parseInt(document.getElementById('minFontSize').value),
        maxFontSize: parseInt(document.getElementById('maxFontSize').value),
        minSpeed: parseInt(document.getElementById('minSpeed').value),
        maxSpeed: parseInt(document.getElementById('maxSpeed').value),
        repeatCount: parseInt(document.getElementById('repeatCount').value),
        colors: [
            document.getElementById('color1').value,
            document.getElementById('color2').value,
            document.getElementById('color3').value,
            document.getElementById('color4').value,
            document.getElementById('color5').value
        ]
    };

    if (settings.gasUrl && !settings.gasUrl.includes('/exec')) {
        showStatus("⚠️ GAS 網址格式可能錯誤", true);
        return;
    }

    chrome.storage.local.set({ settings }, () => {
        showStatus("✅ 已儲存並套用！ ✨");
    });
}

async function clearCloudData() {
    const gasUrl = document.getElementById('gasUrl').value.trim();
    if (!gasUrl) return alert("請先輸入 GAS 網址");

    if (confirm("確定要清空雲端試算表嗎？")) {
        showStatus("⏳ 清空中...");
        try {
            await fetch(gasUrl, {
                method: 'POST',
                mode: 'no-cors',
                body: JSON.stringify({ action: "clear" })
            });
            showStatus("✅ 雲端已清空");
        } catch (e) {
            showStatus("❌ 清空失敗，請檢查網路", true);
        }
    }
}

function showStatus(msg, isError = false) {
    const status = document.getElementById('status');
    status.innerText = msg;
    status.style.color = isError ? '#ef4444' : '#ec4899';
    setTimeout(() => status.innerText = "", 3000);
}
