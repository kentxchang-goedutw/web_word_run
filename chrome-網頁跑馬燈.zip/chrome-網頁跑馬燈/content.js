let settings = {
    isActive: false,
    gasUrl: '',
    minFontSize: 60,
    maxFontSize: 120,
    minSpeed: 8,
    maxSpeed: 15,
    repeatCount: 3,
    colors: ['#ec4899', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6']
};
let lastDataCount = 0;
let fetchTimer = null;
let shadowRoot = null;
let marqueeContainer = null;

console.log("✨ 可愛跑馬燈內容腳本 (Shadow DOM 版) 已載入");

// 初始化 Shadow DOM 容器
function initShadowDOM() {
    if (marqueeContainer) return;

    const host = document.createElement('div');
    host.id = 'cute-marquee-host';
    // 掛載在 documentElement 而非 body，更穩定
    (document.documentElement || document.body).appendChild(host);

    shadowRoot = host.attachShadow({ mode: 'closed' });
    
    // 注入樣式
    const style = document.createElement('style');
    style.textContent = `
        @keyframes cuteMarqueeMove {
            0% { transform: translateX(100vw); }
            100% { transform: translateX(-100%); }
        }
        .marquee-wrapper {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            pointer-events: none;
            z-index: 2147483647;
            overflow: hidden;
            background: transparent;
        }
        .cute-marquee-item {
            position: absolute !important;
            white-space: nowrap !important;
            will-change: transform !important;
            pointer-events: none !important;
            display: flex !important;
            align-items: center !important;
            line-height: 1 !important;
            filter: drop-shadow(4px 4px 0px rgba(0,0,0,0.3)) !important;
            font-family: 'Comic Sans MS', 'Noto Sans TC', cursive, sans-serif !important;
            font-weight: bold !important;
            z-index: 2147483647 !important;
            -webkit-text-stroke: 1px rgba(255,255,255,0.4);
        }
    `;
    shadowRoot.appendChild(style);

    marqueeContainer = document.createElement('div');
    marqueeContainer.className = 'marquee-wrapper';
    shadowRoot.appendChild(marqueeContainer);
    
    console.log("✅ Shadow DOM 容器已建立");
}

// 載入設定
chrome.storage.local.get(['settings'], (result) => {
    if (result.settings) {
        settings = { ...settings, ...result.settings };
        console.log("載入儲存設定:", settings);
    } else {
        console.log("尚無儲存設定，使用預設值");
    }
    
    if (settings.isActive) {
        initShadowDOM();
        createMarqueeItem("🍓 跑馬燈系統啟動成功！");
    }
    checkState();
});

// 監聽設定變更
chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.settings) {
        settings = changes.settings.newValue;
        console.log("設定已更新:", settings);
        if (settings.isActive) initShadowDOM();
        checkState();
    }
});

function checkState() {
    if (settings && settings.isActive && settings.gasUrl) {
        if (!fetchTimer) {
            console.log("🚀 啟動抓取任務");
            fetchData();
        }
    } else {
        console.log("🛑 停止抓取任務");
        stopFetching();
        clearMarquees();
    }
}

function stopFetching() {
    if (fetchTimer) {
        clearTimeout(fetchTimer);
        fetchTimer = null;
    }
}

async function fetchData() {
    if (!settings || !settings.isActive || !settings.gasUrl) {
        console.log("跳過抓取: 設定未啟用或網址無效", { settings });
        return;
    }

    const url = `${settings.gasUrl}${settings.gasUrl.includes('?') ? '&' : '?'}t=${Date.now()}`;
    console.log("🔍 嘗試抓取資料:", url);
    
    try {
        chrome.runtime.sendMessage({ action: "fetchGasData", url: url }, (response) => {
            if (chrome.runtime.lastError) {
                const error = chrome.runtime.lastError.message;
                if (error.includes("context invalidated")) {
                    console.log("⚠️ 擴充功能上下文已失效，停止運作（請重新整理頁面）");
                    stopFetching();
                    return;
                }
                console.error("❌ 通訊失敗 (lastError):", error);
                
                // 如果是通道關閉錯誤，嘗試在 5 秒後重試一次
                if (error.includes("message channel closed")) {
                    console.log("🔄 通道異常關閉，將在 5 秒後重試...");
                    fetchTimer = setTimeout(fetchData, 5000);
                    return;
                }
            }

            if (response && response.success) {
                console.log("📦 成功收到資料，開始處理");
                processRawData(response.data);
            } else {
                console.warn("⚠️ 抓取任務未成功:", response ? response.error : "無回應");
            }

            // 繼續下一次抓取
            if (settings && settings.isActive) {
                fetchTimer = setTimeout(fetchData, 3000);
            }
        });
    } catch (e) {
        if (e.message.includes("context invalidated")) {
            console.log("⚠️ 偵測到上下文失效，停止背景抓取任務。");
            stopFetching();
        } else {
            console.error("❌ sendMessage 發生異常:", e);
        }
    }
}

function processRawData(text) {
    let data;
    try {
        data = JSON.parse(text);
    } catch (e) {
        const match = text.match(/^[^(]+\((.*)\)$/s);
        if (match && match[1]) {
            try { data = JSON.parse(match[1]); } catch (e2) { return; }
        } else { return; }
    }

    if (Array.isArray(data)) {
        if (data.length > lastDataCount) {
            const newItems = data.slice(lastDataCount);
            newItems.forEach((item, index) => {
                setTimeout(() => createMarqueeItem(item["內容"]), index * 800);
            });
            lastDataCount = data.length;
        } else if (data.length < lastDataCount) {
            lastDataCount = data.length;
        }
    }
}

function createMarqueeItem(text) {
    if (!text || !marqueeContainer) return;

    const div = document.createElement('div');
    div.className = 'cute-marquee-item';
    div.innerText = text;

    const size = getRandomInt(settings.minFontSize, settings.maxFontSize);
    const speed = getRandomInt(settings.minSpeed, settings.maxSpeed);
    const color = settings.colors[Math.floor(Math.random() * settings.colors.length)];

    div.style.fontSize = size + 'px';
    div.style.color = color;
    div.style.top = (Math.random() * (window.innerHeight - size - 100)) + 50 + 'px';
    div.style.animation = `cuteMarqueeMove ${speed}s linear ${settings.repeatCount}`;

    marqueeContainer.appendChild(div);
    console.log(`✅ [顯示] ${text}`);

    div.addEventListener('animationend', () => {
        div.remove();
    });
}

function clearMarquees() {
    if (marqueeContainer) {
        marqueeContainer.innerHTML = '';
    }
    lastDataCount = 0;
}

function getRandomInt(min, max) {
    min = parseInt(min); max = parseInt(max);
    if (min > max) [min, max] = [max, min];
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
