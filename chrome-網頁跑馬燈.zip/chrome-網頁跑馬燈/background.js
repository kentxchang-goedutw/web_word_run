// 背景腳本：負責處理跨網域抓取資料，繞過網頁的 CSP 限制
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log("收到訊息:", request);

    if (request.action === "fetchGasData") {
        // 使用立即執行的非同步函式處理，確保 return true 能正確運作
        (async () => {
            try {
                if (!request.url) {
                    throw new Error("URL 為空");
                }
                
                console.log("開始抓取資料:", request.url);
                const response = await fetch(request.url);
                
                if (!response.ok) {
                    throw new Error(`HTTP 錯誤! 狀態碼: ${response.status}`);
                }
                
                const text = await response.text();
                console.log("抓取成功，資料長度:", text.length);
                sendResponse({ success: true, data: text });
            } catch (error) {
                console.error("背景抓取失敗:", error);
                sendResponse({ success: false, error: error.message });
            }
        })();
        
        return true; // 保持通道開啟以進行非同步回傳
    }

    // 對於未知的指令，也應該回覆以關閉通道
    console.warn("收到未知指令:", request.action);
    sendResponse({ success: false, error: "未知指令" });
    return false;
});
